#!/usr/bin/env bash

python -m simpylc -s